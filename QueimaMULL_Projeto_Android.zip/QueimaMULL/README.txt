QUEIMA MULL — projeto Android

O que este projeto faz:
- Cria um aplicativo Android chamado “Queima MULL”.
- Exibe a logomarca MULL UMWELT original na tela inicial.
- Abre o endereço do relatório dentro do próprio aplicativo (WebView).
- Requer internet para carregar o relatório hospedado.

Como gerar o APK:
1. Abra este projeto no Android Studio (Open) em um computador.
2. Aguarde a sincronização do Gradle e a instalação dos componentes Android solicitados.
3. No menu Build, escolha Build Bundle(s) / APK(s) > Build APK(s).
4. O APK de teste ficará em app/build/outputs/apk/debug/app-debug.apk.
5. Transfira o APK ao Moto G56 5G e instale. Se o Android pedir, permita a instalação para o app usado para abrir o arquivo.

Link configurado para o relatório:
https://claude.ai/artifact/TrRUE8JEDw1SrkDAJeqFUQ

Observação: este ambiente não possui Android SDK/Gradle instalados, então o APK binário não foi compilado aqui. O projeto-fonte está pronto para abrir e compilar no Android Studio. O link do relatório deve continuar publicado e acessível para funcionar.

GERAR O APK PELO CELULAR (SEM ANDROID STUDIO):
1. Crie um repositório no GitHub chamado QueimaMULL e envie todos os arquivos/pastas deste ZIP para ele (incluindo a pasta oculta .github).
2. No GitHub, abra a aba Actions e selecione “Gerar APK Queima MULL”.
3. Toque em “Run workflow” e confirme “Run workflow”. (O fluxo também inicia automaticamente quando você envia/atualiza arquivos na branch main.)
4. Quando terminar com sucesso, abra a execução e baixe o artefato “Queima-MULL-APK”.
5. Extraia o arquivo app-debug.apk do ZIP baixado e instale no Android.

O APK gerado pelo GitHub Actions é uma versão debug para instalação/testes. Para publicar na Play Store, será necessário configurar assinatura de lançamento e preparar a versão release.
