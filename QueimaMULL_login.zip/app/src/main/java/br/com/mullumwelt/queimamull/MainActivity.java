package br.com.mullumwelt.queimamull;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.view.Gravity;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.net.Uri;
import android.content.Intent;
import java.util.ArrayList;
import java.util.List;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialException;
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Executor;

public class MainActivity extends Activity {
    private WebView webView;
    private boolean showingReport = false;
    private FirebaseAuth auth;
    private final Executor mainExecutor = r -> new Handler(Looper.getMainLooper()).post(r);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(12, 65, 45));
        getWindow().setNavigationBarColor(Color.rgb(12, 65, 45));
        auth = FirebaseAuth.getInstance();
        FirebaseUser u = auth.getCurrentUser();
        if (u != null && isAllowed(u.getEmail())) showHome();
        else showLogin(null);
    }

    private Set<String> loadAllowed() {
        Set<String> set = new HashSet<>();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(
                getAssets().open("emails_autorizados.txt"), "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim().toLowerCase();
                if (!line.isEmpty() && !line.startsWith("#")) set.add(line);
            }
        } catch (Exception ignored) { }
        return set;
    }

    private boolean isAllowed(String email) {
        return email != null && loadAllowed().contains(email.trim().toLowerCase());
    }

    private void showLogin(String message) {
        showingReport = false;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(32), dp(24), dp(32));
        root.setBackgroundColor(Color.rgb(246, 249, 246));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo_mull);
        logo.setAdjustViewBounds(true);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        root.addView(logo, new LinearLayout.LayoutParams(-1, dp(110)));

        TextView title = text("QUEIMA MULL", 26, Color.rgb(17, 91, 58), true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.topMargin = dp(24); root.addView(title, tp);
        TextView sub = text("Acesso restrito", 16, Color.DKGRAY, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = dp(8); root.addView(sub, sp);

        Button enter = new Button(this);
        enter.setText("ENTRAR COM GOOGLE");
        enter.setTextColor(Color.WHITE);
        enter.setAllCaps(false);
        enter.setTextSize(17);
        enter.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(20, 112, 70)));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(58));
        bp.topMargin = dp(36); root.addView(enter, bp);

        TextView msg = text(message == null ? "" : message, 14, Color.rgb(170, 30, 30), false);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, -2);
        mp.topMargin = dp(20); root.addView(msg, mp);

        enter.setOnClickListener(v -> {
            enter.setEnabled(false);
            msg.setTextColor(Color.DKGRAY);
            msg.setText("Aguarde...");
            signIn(enter, msg);
        });
        setContentView(root);
    }

    private void fail(Button enter, TextView msg, String text) {
        enter.setEnabled(true);
        msg.setTextColor(Color.rgb(170, 30, 30));
        msg.setText(text);
    }

    private void signIn(Button enter, TextView msg) {
        GetSignInWithGoogleOption option = new GetSignInWithGoogleOption.Builder(
                getString(R.string.default_web_client_id)).build();
        GetCredentialRequest request = new GetCredentialRequest.Builder()
                .addCredentialOption(option).build();
        CredentialManager manager = CredentialManager.create(this);
        manager.getCredentialAsync(this, request, new CancellationSignal(), mainExecutor,
            new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                @Override public void onResult(GetCredentialResponse result) {
                    Credential c = result.getCredential();
                    if (c instanceof CustomCredential && GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(c.getType())) {
                        GoogleIdTokenCredential g = GoogleIdTokenCredential.createFrom(((CustomCredential) c).getData());
                        AuthCredential cred = GoogleAuthProvider.getCredential(g.getIdToken(), null);
                        auth.signInWithCredential(cred).addOnCompleteListener(MainActivity.this, task -> {
                            if (!task.isSuccessful()) {
                                fail(enter, msg, "Não foi possível entrar. Verifique a internet e tente de novo.");
                                return;
                            }
                            FirebaseUser u = auth.getCurrentUser();
                            if (u != null && isAllowed(u.getEmail())) {
                                showHome();
                            } else {
                                String mail = u != null ? u.getEmail() : "";
                                auth.signOut();
                                fail(enter, msg, "O e-mail " + mail + " não tem autorização para usar este app.");
                            }
                        });
                    } else {
                        fail(enter, msg, "Tipo de login não reconhecido.");
                    }
                }
                @Override public void onError(GetCredentialException e) {
                    fail(enter, msg, "Login cancelado ou indisponível: " + e.getMessage());
                }
            });
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private void showHome() {
        showingReport = false;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(32), dp(24), dp(32));
        root.setBackgroundColor(Color.rgb(246, 249, 246));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo_mull);
        logo.setAdjustViewBounds(true);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        root.addView(logo, new LinearLayout.LayoutParams(-1, dp(130)));

        TextView title = text("QUEIMA MULL", 26, Color.rgb(17, 91, 58), true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.topMargin = dp(28); root.addView(title, tp);
        TextView subtitle = text("Relatórios de operação", 16, Color.DKGRAY, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = dp(8); root.addView(subtitle, sp);

        Button open = new Button(this);
        open.setText("ABRIR RELATÓRIO DIÁRIO");
        open.setTextColor(Color.WHITE);
        open.setAllCaps(false);
        open.setTextSize(17);
        open.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(20, 112, 70)));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(58));
        bp.topMargin = dp(40); root.addView(open, bp);
        open.setOnClickListener(v -> showReport());

        for (String[] c : loadContacts()) {
            Button wa = new Button(this);
            wa.setText("WhatsApp: " + c[0]);
            wa.setTextColor(Color.WHITE);
            wa.setAllCaps(false);
            wa.setTextSize(16);
            wa.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(18, 140, 126)));
            LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(-1, dp(52));
            wp.topMargin = dp(14); root.addView(wa, wp);
            final String url = whatsappUrl(c[1], c[2]);
            wa.setOnClickListener(v -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                catch (Exception e) { /* sem app para abrir o link */ }
            });
        }

        TextView footer = text("MULL UMWELT\nJuntos por um mundo mais limpo!", 13, Color.rgb(70, 100, 80), false);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.topMargin = dp(36); root.addView(footer, fp);

        FirebaseUser cur = auth.getCurrentUser();
        Button out = new Button(this);
        out.setText("Sair" + (cur != null && cur.getEmail() != null ? " (" + cur.getEmail() + ")" : ""));
        out.setAllCaps(false);
        out.setTextSize(13);
        out.setOnClickListener(v -> { auth.signOut(); showLogin(null); });
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-2, dp(44));
        op.topMargin = dp(24); root.addView(out, op);
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackgroundColor(Color.rgb(246, 249, 246));
        sv.addView(root);
        setContentView(sv);
    }

    private List<String[]> loadContacts() {
        List<String[]> list = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(
                getAssets().open("contatos_whatsapp.txt"), "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                String[] parts = line.split("\\|", -1);
                if (parts.length < 2) continue;
                String name = parts[0].trim();
                String dest = parts[1].trim();
                String msg = parts.length > 2 ? parts[2].trim() : "";
                if (!name.isEmpty() && !dest.isEmpty()) list.add(new String[]{name, dest, msg});
            }
        } catch (Exception ignored) { }
        return list;
    }

    private String whatsappUrl(String dest, String msg) {
        if (dest.startsWith("http")) return dest;
        String digits = dest.replaceAll("[^0-9]", "");
        if (digits.length() <= 11) digits = "55" + digits;
        String url = "https://wa.me/" + digits;
        if (!msg.isEmpty()) url += "?text=" + Uri.encode(msg);
        return url;
    }

    private void showReport() {
        showingReport = true;
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(Color.WHITE);
        Button back = new Button(this);
        back.setText("‹  Voltar ao início"); back.setAllCaps(false);
        back.setOnClickListener(v -> showHome());
        page.addView(back, new LinearLayout.LayoutParams(-1, dp(48)));
        ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        page.addView(progress, new LinearLayout.LayoutParams(-1, dp(3)));
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface public void printPage(final String name) {
                runOnUiThread(() -> {
                    PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                    PrintAttributes attrs = new PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4).build();
                    pm.print(name, webView.createPrintDocumentAdapter(name), attrs);
                });
            }
        }, "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }
        });
        page.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(page);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override public void onBackPressed() {
        if (showingReport) { showHome(); }
        else { super.onBackPressed(); }
    }
}
